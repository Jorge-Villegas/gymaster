import 'package:flutter/material.dart';

class DataSeed extends StatelessWidget {
  const DataSeed({super.key});

  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
