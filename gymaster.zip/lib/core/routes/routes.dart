class Routes {
  static const String home = '/home';
  static const String crearRutina = '/agregar_rutina';
  static const String configuracion = '/configuracion';
  static const String detalleRutina = '/detalle_rutina';
  static const String agregarEjercicio = '/agregar_ejercicio';
  static const String perfilUsuario = '/perfil_usuario';
  static const String detalleEjercicio = '/detalle_ejercicio';
  static const String calendario = '/calendario';
  static const String crearUsuario = '/crear_usuario';
  static const String listarEjercicios = '/ListarEjercicios';
}
